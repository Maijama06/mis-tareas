/* Lógica de "Mis Tareas": urgencia, cuenta regresiva, filtros, alarmas y
   notas. Sin DOM ni red, para poder probarla aparte. */
(function (root) {
  'use strict';

  const DIA = 86400;
  const HORA = 3600;
  const VENTANAS = [24, 6, 1];
  const APROBACION = 70;

  /* nivel: [etiqueta, color, fondo suave, borde, orden] */
  const NIVELES = {
    0: { txt: 'Vencida', corto: 'Vencida', fg: '#e5484d', bg: '#ffedee', borde: '#e5484d', orden: 0 },
    1: { txt: 'Vence hoy', corto: 'Hoy', fg: '#f76808', bg: '#fff4e6', borde: '#f76808', orden: 1 },
    2: { txt: 'Mañana', corto: 'Mañana', fg: '#ffb224', bg: '#fff8e1', borde: '#ffb224', orden: 2 },
    3: { txt: 'Esta semana', corto: 'Semana', fg: '#46a758', bg: '#ebfbee', borde: '#46a758', orden: 3 },
    4: { txt: 'Próxima semana', corto: '+1 sem', fg: '#0091ff', bg: '#e7f5ff', borde: '#0091ff', orden: 4 },
    5: { txt: 'Con tiempo', corto: 'Tranqui', fg: '#8e4ec6', bg: '#f3edfc', borde: '#8e4ec6', orden: 5 },
    6: { txt: 'Sin fecha', corto: 'Sin fecha', fg: '#868e96', bg: '#f1f3f5', borde: '#adb5bd', orden: 6 },
    7: { txt: 'Entregada', corto: 'Hecha', fg: '#2f9e44', bg: '#ebfbee', borde: '#69db7c', orden: 7 },
  };

  /* paleta para las materias */
  const COLORES = ['#e5484d', '#f76808', '#ffb224', '#46a758', '#0091ff',
                   '#8e4ec6', '#e93d82', '#0ca678', '#5c7cfa', '#d64545'];

  /* ------------------------------------------------------------ tiempo */
  function duracion(seg) {
    seg = Math.max(0, Math.floor(seg));
    const d = Math.floor(seg / DIA);
    const h = Math.floor((seg % DIA) / HORA);
    const m = Math.floor((seg % HORA) / 60);
    const partes = [];
    if (d) partes.push(d + (d === 1 ? ' día' : ' días'));
    if (h) partes.push(h + ' h');
    if (m && !d) partes.push(m + ' min');
    return partes.join(' ') || '0 min';
  }

  function diasDeCalendario(a, b) {
    const x = new Date(a * 1000);
    const y = new Date(b * 1000);
    return Math.round(
      (Date.UTC(y.getFullYear(), y.getMonth(), y.getDate())
       - Date.UTC(x.getFullYear(), x.getMonth(), x.getDate())) / 86400000);
  }

  function urgencia(entrega, ahora) {
    if (entrega === null || entrega === undefined) return NIVELES[6];
    const ref = ahora || ahora_();
    const d = entrega - ref;
    if (d < 0) return NIVELES[0];
    const dias = diasDeCalendario(ref, entrega);
    if (dias <= 0) return NIVELES[1];
    if (dias === 1) return NIVELES[2];
    if (dias <= 7) return NIVELES[3];
    if (dias <= 14) return NIVELES[4];
    return NIVELES[5];
  }

  function cuentaRegresiva(entrega, ahora) {
    if (entrega === null || entrega === undefined) return 'sin fecha';
    const ref = ahora || ahora_();
    const d = entrega - ref;
    if (d < 0) return 'venció hace ' + duracion(-d);
    if (d < HORA) return 'faltan ' + Math.max(1, Math.floor(d / 60)) + ' min';
    return 'faltan ' + duracion(d);
  }

  function fechaLarga(ts) {
    if (!ts) return 'Sin fecha';
    const f = new Date(ts * 1000);
    return f.toLocaleDateString('es-EC', { weekday: 'short', day: 'numeric', month: 'short' })
         + ' · ' + f.toLocaleTimeString('es-EC', { hour: '2-digit', minute: '2-digit' });
  }

  function ahora_() { return Math.floor(Date.now() / 1000); }

  /* ---------------------------------------------------------- validación */
  // Devuelve un objeto de errores; vacío = todo bien.
  function validar(d) {
    const e = {};
    if (!d.titulo || !d.titulo.trim()) e.titulo = 'Ponle un nombre a la tarea';
    else if (d.titulo.trim().length > 120) e.titulo = 'El nombre es muy largo (máx 120)';
    if (d.entrega !== null && d.entrega !== undefined && !Number.isFinite(d.entrega)) {
      e.entrega = 'La fecha no es válida';
    }
    for (const campo of ['puntos', 'nota']) {
      const v = d[campo];
      if (v === null || v === undefined || v === '') continue;
      const n = Number(v);
      if (!Number.isFinite(n) || n < 0) e[campo] = 'No puede ser negativo';
    }
    if (d.puntos !== null && d.nota !== null && d.puntos !== '' && d.nota !== ''
        && Number(d.nota) > Number(d.puntos)) {
      e.nota = 'La nota no puede ser mayor que los puntos';
    }
    return e;
  }

  function idAleatorio() {
    return 't' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  // "" , null, undefined y NaN se guardan como null (no como 0: un 0 sería
  // "entregó en 1970" y haría que la tarea saliera vencida siempre).
  function aNum(v) {
    if (v === null || v === undefined || v === '') return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }

  function crearTarea(d, ref) {
    const ahora = ref || ahora_();
    return {
      id: d.id || idAleatorio(),
      titulo: (d.titulo || '').trim(),
      materia: d.materia || '',
      entrega: aNum(d.entrega),
      puntos: aNum(d.puntos),
      nota: aNum(d.nota),
      notaTexto: d.notaTexto || '',
      hecha: !!d.hecha,
      creada: ahora,
      avisos: Array.isArray(d.avisos) ? d.avisos.slice() : [],
    };
  }

  /* ------------------------------------------------------ lista y filtros */
  const VISTAS = ['pendientes', 'hoy', 'semana', 'vencidas', 'hechas', 'todas'];

  function enVista(t, vista, ahora) {
    const ref = ahora || ahora_();
    switch (vista) {
      case 'todas': return true;
      case 'hechas': return t.hecha;
      case 'pendientes': return !t.hecha;
      case 'vencidas': return !t.hecha && t.entrega !== null && t.entrega < ref;
      case 'hoy': {
        if (t.hecha || t.entrega === null) return false;
        return diasDeCalendario(ref, t.entrega) === 0 && t.entrega >= ref;
      }
      case 'semana': {
        if (t.hecha || t.entrega === null) return false;
        // Si ya pasó la hora, aunque sea del mismo día, va en "Vencidas": si no,
        // sale en Semana con la etiqueta roja al lado de un título que dice Hoy.
        if (t.entrega < ref) return false;
        return diasDeCalendario(ref, t.entrega) <= 7;
      }
      default: return true;
    }
  }

  function normalizar(s) {
    return (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  }

  function filtrar(tareas, opciones) {
    const o = opciones || {};
    const ref = o.ahora || ahora_();
    const vista = o.vista || 'pendientes';
    const busqueda = normalizar(o.busqueda || '');
    return tareas.filter((t) => {
      if (!enVista(t, vista, ref)) return false;
      if (o.materia && o.materia !== '__todas__' && t.materia !== o.materia) return false;
      if (busqueda) {
        const heno = normalizar(t.titulo + ' ' + t.materia + ' ' + (t.notaTexto || ''));
        if (heno.indexOf(busqueda) === -1) return false;
      }
      return true;
    });
  }

  function ordenar(tareas, ref) {
    const ahora = ref || ahora_();
    return tareas.slice().sort((a, b) => {
      if (a.hecha !== b.hecha) return a.hecha ? 1 : -1;          // hechas al final
      if (a.entrega === null && b.entrega !== null) return 1;    // sin fecha al fondo
      if (b.entrega === null && a.entrega !== null) return -1;
      if (a.entrega !== b.entrega) return (a.entrega || 0) - (b.entrega || 0);
      return (a.materia || '').localeCompare(b.materia || '') || a.titulo.localeCompare(b.titulo);
    });
  }

  function resumen(tareas, ref) {
    const ahora = ref || ahora_();
    const r = { total: 0, pendientes: 0, hechas: 0, vencidas: 0, hoy: 0, semana: 0, sinFecha: 0 };
    tareas.forEach((t) => {
      r.total++;
      if (t.hecha) { r.hechas++; return; }
      r.pendientes++;
      if (t.entrega === null) { r.sinFecha++; return; }
      const d = diasDeCalendario(ahora, t.entrega);
      if (t.entrega < ahora) {
        r.vencidas++;
      } else if (d === 0) {
        r.hoy++;
        r.semana++;   // la pestaña "Semana" sí incluye lo de hoy; el contador debe coincidir
      } else if (d <= 7) {
        r.semana++;
      }
    });
    return r;
  }

  /* -------------------------------------------------------------- notas */
  // Progreso: cuántos puntos llevas sobre el total posible. Los puntos posibles
  // cuentan para TODAS las tareas (también las pendientes): si no, una tarea
  // grande sin entregar infla tu promedio y parecería que vas mejor de lo que vas.
  function progreso(tareas) {
    const r = {
      entregadas: 0, total: 0, puntos: 0, posibles: 0,
      nota: null, aprobado: null, quedan: 0,
    };
    tareas.forEach((t) => {
      r.total++;
      if (t.hecha) r.entregadas++;
      else r.quedan++;
      const posibles = Number(t.puntos);
      if (Number.isFinite(posibles) && posibles > 0) r.posibles += posibles;
      const nota = Number(t.nota);
      if (t.hecha && Number.isFinite(nota) && nota >= 0) r.puntos += nota;
    });
    r.nota = r.posibles > 0 ? (r.puntos / r.posibles) * 100 : null;
    if (r.nota !== null) r.aprobado = r.nota >= APROBACION;
    return r;
  }

  /* ------------------------------------------------------------ alarmas */
  function planAlarmas(tareas, ref, ventanas) {
    const ahora = ref || ahora_();
    const vent = ventanas || VENTANAS;
    const plan = [];
    tareas.forEach((t) => {
      if (t.hecha || t.entrega === null) return;
      const faltan = t.entrega - ahora;
      if (faltan <= 0) return;
      vent.forEach((h) => {
        if (faltan <= h * HORA && t.avisos.indexOf(h + 'h') === -1) {
          plan.push({ tarea: t, horas: h });
        }
      });
    });
    return plan;
  }

  function textoAlarma(t, horas, ref) {
    const faltan = t.entrega - (ref || ahora_());
    if (horas <= 1) return '¡Última hora! Cierra en ' + duracion(faltan);
    if (horas <= 6) return 'Cierra en ' + duracion(faltan) + ' — apúrate';
    return 'Cierra en ' + duracion(faltan);
  }

  function aplicarAlarmas(plan, tareas) {
    const copia = tareas.map((t) => Object.assign({}, t, { avisos: (t.avisos || []).slice() }));
    const porId = {};
    copia.forEach((t) => { porId[t.id] = t; });
    plan.forEach((p) => {
      const t = porId[p.tarea.id];
      if (t && t.avisos.indexOf(p.horas + 'h') === -1) t.avisos.push(p.horas + 'h');
    });
    return copia;
  }

  const API = {
    DIA, HORA, VENTANAS, APROBACION, NIVELES, COLORES, VISTAS,
    duracion, diasDeCalendario, urgencia, cuentaRegresiva, fechaLarga, ahora: ahora_,
    validar, crearTarea, idAleatorio,
    enVista, normalizar, filtrar, ordenar, resumen, progreso,
    planAlarmas, textoAlarma, aplicarAlarmas,
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  else root.MT = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
