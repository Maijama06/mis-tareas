/* Service worker de "Mis Tareas".
   Nota: los avisos de vencimiento solo pueden dispararse con la app abierta
   (o minimizada). El navegador congela los temporizadores en segundo plano y
   no hay forma de programar notificaciones para más tarde desde una web. */
const CACHE = 'mis-tareas-v1';
const ARCHIVOS = ['./', 'index.html', 'app.js', 'logica.js',
                  'manifest.webmanifest', 'icono-192.png', 'icono-512.png'];

self.addEventListener('install', (ev) => {
  ev.waitUntil(
    caches.open(CACHE)
      .then((c) => Promise.allSettled(ARCHIVOS.map((a) => c.add(a))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (ev) => {
  ev.waitUntil(
    caches.keys()
      .then((n) => Promise.all(n.filter((x) => x !== CACHE).map((x) => caches.delete(x))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (ev) => {
  if (ev.request.method !== 'GET') return;
  const url = new URL(ev.request.url);
  if (url.origin !== self.location.origin) return;
  // Red primero: si no, con abrir la app una vez nunca se vería una versión nueva.
  ev.respondWith(
    fetch(ev.request)
      .then((r) => {
        if (r && r.ok) {
          const copia = r.clone();
          caches.open(CACHE).then((c) => c.put(ev.request, copia));
        }
        return r;
      })
      .catch(() => caches.match(ev.request).then((x) => x || caches.match('./')))
  );
});

self.addEventListener('notificationclick', (ev) => {
  ev.notification.close();
  ev.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then((vs) => {
        for (const v of vs) if ('focus' in v) return v.focus();
        return self.clients.openWindow('./');
      })
  );
});
