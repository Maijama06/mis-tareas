# Mis Tareas

App para el celular que registra **a mano** las tareas que te asignan, las
ordena por urgencia y te avisa con sonido y vibración antes de que se cierren.

No se conecta a nada: entras tú las tareas y la app te hace el resto.

![Mis Tareas](captura.png)

## Lo que ya trae

Las 5 materias del semestre, listas para usar:

- Cálculo diferencial
- Probabilidad y estadística
- Circuitos eléctricos
- Métodos numéricos
- Software de simulación

Puedes renombrarlas, cambiarles el color o borrarlas en **Ajustes → Materias**.

## Cómo ponerla en el teléfono

Es una PWA: necesita una dirección web. La forma más fácil de probarla ahora
es desde el computador y la misma red:

```powershell
node ver.js
```

El comando imprime dos direcciones. Abre en el celular la que dice
"En tu celular" (por ejemplo `http://192.168.0.15:8090`) y ahí la tienes.
Agrega `?demo=1` si quieres verla con tareas de ejemplo.

### Para dejarla instalada de verdad

Los avisos con sonido necesitan `https` o `localhost`, así que desde el
computador en la red local **no van a sonar** (el resto funciona). Para tener
todo:

1. Sube estos archivos a un repositorio de GitHub.
2. **Settings → Pages → Source: main / root → Save**.
3. Abre la dirección que te da (tipo `https://tuousuario.github.io/mis-tareas`)
   en Chrome y toca **Instalar**.

Ya instalada se abre sola, a pantalla completa, con su ícono en el escritorio.
Nada de lo que registres se sube a internet: vive en tu teléfono.

## Para qué sirve cada cosa

| | |
|---|---|
| **Registrar** | Botón **+**: nombre, materia y cuándo cierra. Nada más es obligatorio. |
| **Ordenar por urgencia** | `Vencida` · `Vence hoy` · `Mañana` · `Esta semana` · `Próxima semana` · `Con tiempo`, cada una con su color. Lo vencido siempre arriba. |
| **Agrupar** | Encabezados por día para ver de un vistazo qué vence hoy, qué mañana y qué la semana que viene. |
| **Alarmas** | 24 h, 6 h y 1 h antes del cierre. Las últimas con sonido largo y vibración ("¡Última hora!"). Cada alarma suena **una sola vez**. |
| **Entregar** | Toca el cuadrito de la izquierda y la tarea pasa a "Hechas". |
| **Deslizar** | Arrastra la tarjeta a la izquierda para editar o borrar. |
| **Buscar** | Lupa arriba: por nombre de tarea o de materia. No le importan los acentos ni las mayúsculas. |
| **Puntos y nota** | Opcional. Si los anotas, Ajustes te muestra tu promedio: **verde si es 70 o más, rojo si no**. |
| **Temas** | Claro, oscuro o "como el sistema". Con el ícono del sol/luna, arriba a la derecha. |
| **Copia de seguridad** | Ajustes → *Exportar copia* descarga un `.json`. *Restaurar* lo vuelve a subir. |

## Lo que NO puede hacer (importante)

**Los avisos solo funcionan con la app abierta.** Android congela las apps web
cuando están en segundo plano, así que:

- Abierta o minimizada: revisa cada 5 minutos y avisa. ✅
- Cerrada del todo: no puede avisarte. ❌

Cada vez que abres la app revisa al instante y te avisa de lo que se te pasó.
No hay forma desde una web de programar avisos para más tarde; eso necesita una
app nativa de Android o un servidor de notificaciones.

También conviene revisar en los ajustes de tu teléfono que el navegador no
mate la app en segundo plano (batería → *sin restricciones*).

## Archivos

| Archivo | Para qué |
|---|---|
| `index.html` | La interfaz y los estilos. |
| `app.js` | Guardado, listas, búsqueda, avisos y ajustes. |
| `logica.js` | Urgencia, cuenta regresiva, filtros, alarmas y promedio. Sin DOM ni red. |
| `sw.js` | Service worker: para poder instalarla y para que abra sin internet. |
| `manifest.webmanifest` | Datos de la app instalada. |
| `ver.js` | Levanta un servidor local para probarla. |
| `generar_iconos.py` | Regenera los íconos. |
| `pruebas.js` | 77 pruebas de la lógica. `node pruebas.js` |
| `prueba_ui.js` | 97 pruebas de la interfaz real. `node prueba_ui.js` |

## Pruebas

```powershell
node pruebas.js        # lógica: urgencia, filtros, alarmas, promedio
node prueba_ui.js      # interfaz: correr la app de verdad y revisar lo que dibuja
```

`prueba_ui.js` necesita [jsdom](https://github.com/jsdom/jsdom):

```powershell
npm install jsdom
```

Ninguna de las dos necesita internet.
