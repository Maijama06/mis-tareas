/* Mis Tareas: interfaz, guardado y avisos. */
(function () {
  'use strict';

  const L = window.MT;
  const CLAVE = 'mis_tareas_v1';
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => Array.from(document.querySelectorAll(s));

  const ICONOS = {
    lupa: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
    engranaje: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2V21a2 2 0 1 1-4 0v-.1A1.7 1.7 0 0 0 7 19.4a1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0-1.2-2.9H1a2 2 0 1 1 0-4h.1A1.7 1.7 0 0 0 2.6 7a1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H7a1.7 1.7 0 0 0 1-1.5V1a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V7a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
    sol: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="4.5"/><path d="M12 2v2M12 20v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2 12h2M20 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/></svg>',
    luna: '<svg viewBox="0 0 24 24"><path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z"/></svg>',
    check: '<svg viewBox="0 0 24 24"><path d="M4 12l6 6L20 6"/></svg>',
    reloj: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3.5 2"/></svg>',
    aviso: '<svg viewBox="0 0 24 24"><path d="M12 3l9.5 17H2.5z"/><path d="M12 9v5M12 17.2v.1"/></svg>',
    raya: '<svg viewBox="0 0 24 24"><path d="M4 12h16"/></svg>',
    lapiz: '<svg viewBox="0 0 24 24"><path d="M4 20h4L20 8l-4-4L4 16z"/></svg>',
    basura: '<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14"/></svg>',
    mas: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
    campana: '<svg viewBox="0 0 24 24"><path d="M6 9a6 6 0 1 1 12 0c0 5 2 6 2 6H4s2-1 2-6z"/><path d="M10 20a2.5 2.5 0 0 0 4 0"/></svg>',
    rayo: '<svg viewBox="0 0 24 24"><path d="M13 2L4 14h6l-1 8 9-12h-6z"/></svg>',
    grafico: '<svg viewBox="0 0 24 24"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>',
  };

  const TABS = [
    { id: 'pendientes', txt: 'Pendientes' },
    { id: 'hoy', txt: 'Hoy' },
    { id: 'semana', txt: 'Semana' },
    { id: 'vencidas', txt: 'Vencidas' },
    { id: 'hechas', txt: 'Hechas' },
    { id: 'todas', txt: 'Todas' },
  ];

  // Las materias del semestre, listas para usar desde el primer día.
  // Se pueden renombrar, cambiar de color o borrar en Ajustes.
  const MATERIAS_INICIALES = [
    { nombre: 'Cálculo diferencial',    color: '#4c6ef5' },
    { nombre: 'Probabilidad y estadística', color: '#8e4ec6' },
    { nombre: 'Circuitos eléctricos',   color: '#f76808' },
    { nombre: 'Métodos numéricos',      color: '#0091ff' },
    { nombre: 'Software de simulación', color: '#0ca678' },
  ];

  let datos = null;
  let vista = 'pendientes';
  let materiaFiltro = '__todas__';
  let busqueda = '';
  let editando = null;      // id de la tarea en edición
  let colorElegida = L.COLORES[0];
  let temporizador = null;
  let audio = null;
  let notificacionesOk = false;

  /* ══════════════════════════════════════════════════════ ARRANQUE */
  function porDefecto() {
    return {
      version: 1,
      tareas: [],
      materias: [],
      vista: 'pendientes',
      tema: 'auto',
      avisos: true,
      alarma: true,
      visto: false,
      ultimaRevision: null,
    };
  }

  function cargar() {
    try {
      const crudo = localStorage.getItem(CLAVE);
      datos = crudo ? Object.assign(porDefecto(), JSON.parse(crudo)) : porDefecto();
    } catch (e) { datos = porDefecto(); }
    if (!Array.isArray(datos.tareas)) datos.tareas = [];
    if (!Array.isArray(datos.materias)) datos.materias = [];
    // Primera vez: dejamos las materias del semestre ya puestas.
    if (!datos.materias.length && !datos.tareas.length) {
      datos.materias = MATERIAS_INICIALES.map((m, i) => ({
        id: 'm' + i, nombre: m.nombre, color: m.color,
      }));
      guardar();
    }
    vista = datos.vista || 'pendientes';
    aplicarTema(datos.tema);
  }

  function guardar() {
    datos.vista = vista;
    try { localStorage.setItem(CLAVE, JSON.stringify(datos)); } catch (e) { /* modo privado */ }
  }

  function aplicarTema(t) {
    let real = t;
    if (t === 'auto') {
      real = (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'oscuro' : 'claro';
    }
    document.documentElement.setAttribute('data-tema', real);
    const meta = document.getElementById('temaColor');
    if (meta) meta.setAttribute('content', real === 'oscuro' ? '#0e1014' : '#f8f9fb');
    const btn = $('#btnTema');
    if (btn) btn.innerHTML = real === 'oscuro' ? ICONOS.sol : ICONOS.luna;
  }

  /* ══════════════════════════════════════════════════════ UTILIDADES */
  function esc(s) {
    return String(s === null || s === undefined ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function materia(id) {
    return datos.materias.find((m) => m.id === id) || null;
  }

  function nombreMateria(id) {
    const m = materia(id);
    return m ? m.nombre : (id ? id : 'Sin materia');
  }

  function colorMateria(id) {
    const m = materia(id);
    return m ? m.color : '#868e96';
  }

  function aEpoch(fecha, hora) {
    if (!fecha) return null;
    const [a, m, d] = fecha.split('-').map(Number);
    const [hh, mm] = (hora || '23:59').split(':').map(Number);
    return Math.floor(new Date(a, (m || 1) - 1, d || 1, hh || 0, mm || 0, 0, 0).getTime() / 1000);
  }

  function desdeEpoch(ts) {
    if (!ts) return { fecha: '', hora: '' };
    const f = new Date(ts * 1000);
    const p = (n) => String(n).padStart(2, '0');
    return { fecha: `${f.getFullYear()}-${p(f.getMonth() + 1)}-${p(f.getDate())}`,
             hora: `${p(f.getHours())}:${p(f.getMinutes())}` };
  }

  function vibrar(ms) { if (navigator.vibrate) navigator.vibrate(ms || 12); }

  function toner(urgente) {
    try {
      if (!audio) audio = new (window.AudioContext || window.webkitAudioContext)();
      if (audio.state === 'suspended') audio.resume();
      const t0 = audio.currentTime;
      const notas = urgente ? [880, 1174, 880] : [784];
      notas.forEach((f, i) => {
        const osc = audio.createOscillator();
        const vol = audio.createGain();
        osc.type = 'sine';
        osc.frequency.value = f;
        const ini = t0 + i * 0.2;
        vol.gain.setValueAtTime(0.0001, ini);
        vol.gain.exponentialRampToValueAtTime(0.22, ini + 0.03);
        vol.gain.exponentialRampToValueAtTime(0.0001, ini + 0.17);
        osc.connect(vol).connect(audio.destination);
        osc.start(ini); osc.stop(ini + 0.19);
      });
    } catch (e) { /* el sonido es un extra */ }
  }

  function brindis(txt, color, icono) {
    const b = $('#brindis');
    $('#brindisTxt').textContent = txt;
    const ic = $('#brindisIc');
    ic.style.background = color;
    ic.innerHTML = icono || ICONOS.check;
    b.classList.add('ver');
    clearTimeout(brindis._t);
    brindis._t = setTimeout(() => b.classList.remove('ver'), 2400);
  }

  /* ══════════════════════════════════════════════════════ AVISOS */
  function pedirNotificaciones() {
    if (!('Notification' in window)) {
      brindis('Este navegador no soporta avisos', '#f76808', ICONOS.aviso);
      return;
    }
    if (Notification.permission === 'granted') {
      notificacionesOk = true;
      brindis('Avisos activados', '#30a46c', ICONOS.campana);
      revisar(true);
      return;
    }
    Notification.requestPermission().then((p) => {
      notificacionesOk = p === 'granted';
      brindis(notificacionesOk ? '¡Avisos activados!' : 'Permiso denegado',
              notificacionesOk ? '#30a46c' : '#e5484d',
              notificacionesOk ? ICONOS.campana : ICONOS.aviso);
      if (notificacionesOk) revisar(true);
    });
  }

  function notificar(titulo, cuerpo, urgente) {
    if (datos.avisos) { toner(urgente); vibrar(urgente ? [110, 60, 110] : 80); }
    if (!notificacionesOk) return;
    if (navigator.serviceWorker) {
      navigator.serviceWorker.ready
        .then((reg) => reg.showNotification(titulo, {
          body: cuerpo, icon: 'icono-192.png', badge: 'icono-192.png',
          tag: 'tareas', renotify: !!urgente,
        }))
        .catch(() => {});
    }
  }

  // Revisa vencimientos y avisa una sola vez por ventana.
  function revisar(forzar) {
    const pendientes = datos.tareas.filter((t) => !t.hecha);
    const plan = L.planAlarmas(pendientes);
    if (!plan.length && !forzar) return;
    if (plan.length) {
      datos.tareas = L.aplicarAlarmas(plan, datos.tareas);
      guardar();
    }
    plan.forEach((p) => {
      const urgente = p.horas <= 6;
      notificar(
        urgente ? '¡Última hora!' : 'Tarea por cerrarse',
        nombreMateria(p.tarea.materia) + '\n' + p.tarea.titulo + '\n' + L.textoAlarma(p.tarea, p.horas),
        urgente
      );
    });
    if (plan.length) pintar();
  }

  function programar() {
    if (temporizador) clearInterval(temporizador);
    temporizador = setInterval(() => revisar(false), 5 * 60 * 1000);
  }

  /* ══════════════════════════════════════════════════════ PINTAR */
  function pintar() {
    pintarResumen();
    pintarTabs();
    pintarLista();
  }

  function pintarResumen() {
    const r = L.resumen(datos.tareas);
    const celdas = [
      { k: 'vencidas', n: r.vencidas, t: 'Vencidas' },
      { k: 'hoy', n: r.hoy, t: 'Hoy' },
      { k: 'semana', n: r.semana, t: 'Semana' },
      { k: 'hechas', n: r.hechas, t: 'Hechas' },
    ];
    $('#resumen').innerHTML = celdas.map((c) =>
      `<button class="stat ${c.k}" data-vista="${c.k}"><b>${c.n}</b><span>${c.t}</span></button>`
    ).join('');
  }

  function pintarTabs() {
    const r = L.resumen(datos.tareas);
    const cuenta = {
      pendientes: r.pendientes, hoy: r.hoy, semana: r.semana,
      vencidas: r.vencidas, hechas: r.hechas, todas: r.total,
    };
    const partes = TABS.map((t) =>
      `<button class="tab ${t.id === vista ? 'on' : ''}" data-vista="${t.id}">${t.txt}<span class="n">${cuenta[t.id] || 0}</span></button>`
    );
    // filtro por materia, si hay más de una
    if (datos.materias.length > 1) {
      partes.push(`<button class="tab ${materiaFiltro === '__todas__' ? '' : 'on'}" data-materia="__todas__">Todas las materias</button>`);
      datos.materias.forEach((m) => {
        const n = datos.tareas.filter((t) => t.materia === m.id).length;
        partes.push(`<button class="tab ${materiaFiltro === m.id ? 'on' : ''}" data-materia="${esc(m.id)}">${esc(m.nombre)}<span class="n">${n}</span></button>`);
      });
    }
    $('#tabs').innerHTML = partes.join('');
  }

  function pintarLista() {
    const ahora = L.ahora();
    const filtradas = L.ordenar(L.filtrar(datos.tareas, { vista, materia: materiaFiltro, busqueda, ahora }));
    const cont = $('#lista');

    if (!filtradas.length) {
      cont.innerHTML = vacio();
      return;
    }

    // agrupar por día, para que se lea de un vistazo
    let html = '';
    let grupo = null;
    filtradas.forEach((t) => {
      const clave = claveGrupo(t, ahora);
      if (clave !== grupo) { grupo = clave; html += `<div class="dia">${esc(TITULOS_GRUPO[clave])}</div>`; }
      html += tarjeta(t, ahora);
    });
    cont.innerHTML = html;
    enlazarTarjetas(cont);
  }

  const TITULOS_GRUPO = {
    vencidas: 'Vencidas', hoy: 'Hoy', manana: 'Mañana', semana: 'Esta semana',
    proxima: 'Próxima semana', holgado: 'Con tiempo', sinfecha: 'Sin fecha', hechas: 'Entregadas',
  };

  // Una sola función decide el grupo y su título: si se calcularan por separado
  // aparecerían dos encabezados "Vencidas" o una tarjeta roja bajo "Hoy".
  function claveGrupo(t, ahora) {
    if (t.hecha) return 'hechas';
    if (t.entrega === null) return 'sinfecha';
    if (t.entrega < ahora) return 'vencidas';
    const d = L.diasDeCalendario(ahora, t.entrega);
    if (d <= 0) return 'hoy';
    if (d === 1) return 'manana';
    if (d <= 7) return 'semana';
    if (d <= 14) return 'proxima';
    return 'holgado';
  }

  function tarjeta(t, ahora) {
    const niv = t.hecha ? L.NIVELES[7] : L.urgencia(t.entrega, ahora);
    const col = colorMateria(t.materia);
    const m = materia(t.materia);
    const cuenta = t.hecha ? 'Entregada' : L.cuentaRegresiva(t.entrega, ahora);
    const puntos = t.puntos === null || t.puntos === undefined ? '' :
      (t.nota === null || t.nota === undefined)
        ? `<span class="pill" style="background:var(--carta2);color:var(--txt2)">vale <b>${t.puntos}</b></span>`
        : `<span class="pill" style="background:#ebfbee;color:#2f9e44">${t.nota} / ${t.puntos}</span>`;

    return `
<div class="tarea ${t.hecha ? 'hecha' : ''}" style="--borde:${niv.borde}" data-id="${esc(t.id)}">
  <div class="t-acciones">
    <button class="editar" data-accion="editar" aria-label="Editar">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="width:17px;height:17px"><path d="M4 20h4L20 8l-4-4L4 16z"/></svg><br>Editar
    </button>
    <button class="borrar" data-accion="borrar" aria-label="Borrar">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="width:17px;height:17px"><path d="M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14"/></svg><br>Borrar
    </button>
  </div>
  <div class="envoltorio">
    <div class="t-cab">
      <button class="check" data-accion="alternar" aria-label="Marcar como entregada">${ICONOS.check}</button>
      <div class="t-cuerpo">
        <div class="t-titulo">${esc(t.titulo)}</div>
        <div class="t-meta">
          <span class="pill" style="background:${niv.bg};color:${niv.fg}">${esc(niv.txt)}</span>
          ${m ? `<span class="materia" style="background:color-mix(in srgb, ${col} 14%, transparent);color:${col}"><i></i>${esc(m.nombre)}</span>` : ''}
          ${puntos}
        </div>
        <div class="t-cuenta">${ICONOS.reloj}${esc(cuenta)} · ${esc(L.fechaLarga(t.entrega))}</div>
        ${t.notaTexto ? `<div class="t-nota">${esc(t.notaTexto)}</div>` : ''}
      </div>
    </div>
  </div>
</div>`;
  }

  function vacio() {
    if (busqueda) {
      return `<div class="vacio"><div class="emo">🔍</div><h3>Sin resultados</h3>
        <p>No encontré nada con "${esc(busqueda)}".</p>
        <button class="btn sec" onclick="document.getElementById('btnBuscar').click()">Cambiar búsqueda</button></div>`;
    }
    const textos = {
      pendientes: ['🎉', 'Nada pendiente', 'No tienes tareas por entregar. Disfruta el respiro.'],
      hoy: ['☀️', 'Nada para hoy', 'No vence nada hoy. Mira "Semana" para lo que se acerca.'],
      semana: ['📅', 'Semana tranquila', 'No tienes entregas en los próximos 7 días.'],
      vencidas: ['👏', 'Nada vencido', 'Estás al día. Ninguna tarea pasó de fecha.'],
      hechas: ['📥', 'Todavía nada', 'Aquí verás las tareas que ya entregaste.'],
      todas: ['📝', 'Empieza tu lista', 'Toca el botón + y registra tu primera tarea.'],
    };
    const t = textos[vista] || textos.pendientes;
    return `<div class="vacio"><div class="emo">${t[0]}</div><h3>${t[1]}</h3><p>${t[2]}</p>
      ${vista === 'todas' || vista === 'pendientes'
        ? '<button class="btn" data-accion="nueva">+ Agregar tarea</button>'
        : '<button class="btn sec" data-vista="todas">Ver todas</button>'}</div>`;
  }

  /* deslizar para editar/borrar */
  function enlazarTarjetas(cont) {
    cont.querySelectorAll('.tarea').forEach((card) => {
      const env = card.querySelector('.envoltorio');
      let x0 = null, y0 = null, abierto = false, movido = false;

      const abrir = () => { env.style.transform = 'translateX(-120px)'; abierto = true; };
      const cerrar = () => { env.style.transform = ''; abierto = false; };

      card.addEventListener('touchstart', (e) => {
        x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; movido = false;
      }, { passive: true });

      card.addEventListener('touchmove', (e) => {
        if (x0 === null) return;
        const dx = e.touches[0].clientX - x0;
        const dy = e.touches[0].clientY - y0;
        if (Math.abs(dy) > Math.abs(dx)) { x0 = null; return; }   // es scroll vertical
        movido = true;
        const base = abierto ? -120 : 0;
        let x = base + dx;
        if (x > 0) x = 0;
        env.style.transform = `translateX(${x}px)`;
      }, { passive: true });

      card.addEventListener('touchend', () => {
        if (x0 === null) return;
        const m = env.style.transform.match(/translateX\((-?[\d.]+)px\)/);
        const final = m ? parseFloat(m[1]) : 0;
        if (final < -55) abrir(); else cerrar();
        x0 = null;
        if (!movido) return;
      });

      card.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-accion]');
        if (!btn) return;
        e.stopPropagation();
        if (abierto && !btn.classList.contains('borrar')) { cerrar(); return; }
        const accion = btn.dataset.accion;
        if (accion === 'alternar') alternar(card.dataset.id);
        else if (accion === 'editar') { cerrar(); abrirHoja(card.dataset.id); }
        else if (accion === 'borrar') borrar(card.dataset.id);
        else if (accion === 'nueva') abrirHoja(null);
      });
    });

    cont.querySelectorAll('[data-vista]').forEach((b) =>
      b.addEventListener('click', () => cambiarVista(b.dataset.vista)));
  }

  /* ══════════════════════════════════════════════════════ ACCIONES */
  function alternar(id) {
    const t = datos.tareas.find((x) => x.id === id);
    if (!t) return;
    t.hecha = !t.hecha;
    if (t.hecha) vibrar(20);
    guardar();
    pintar();
    if (t.hecha) brindis('¡Entregada! Well done', '#30a46c', ICONOS.check);
  }

  function borrar(id) {
    const t = datos.tareas.find((x) => x.id === id);
    if (!t) return;
    if (!confirm(`¿Borrar "${t.titulo}"?`)) return;
    datos.tareas = datos.tareas.filter((x) => x.id !== id);
    guardar();
    pintar();
    brindis('Tarea borrada', '#e5484d', ICONOS.basura);
  }

  function cambiarVista(v) {
    vista = v;
    guardar();
    pintar();
    $('#cuerpo').scrollIntoView && window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /* ══════════════════════════════════════════════════════ HOJA TAREA */
  function abrirHoja(id) {
    editando = id;
    const t = id ? datos.tareas.find((x) => x.id === id) : null;
    $('#tituloHoja').textContent = t ? 'Editar tarea' : 'Nueva tarea';

    const f = t ? desdeEpoch(t.entrega) : { fecha: '', hora: '' };
    const enUnaHora = !t && new Date(Date.now() + 3600e3);
    const porDefectoF = t ? f.fecha : (enUnaHora ? desdeEpoch(Math.floor(enUnaHora.getTime() / 1000)).fecha : '');
    const porDefectoH = t ? f.hora : '23:59';

    const chips = datos.materias.length
      ? datos.materias.map((m) =>
          `<button class="chip-m ${m.id === (t ? t.materia : materiaFiltro) ? 'on' : ''}" data-mat="${esc(m.id)}">
             <i style="background:${m.color}"></i>${esc(m.nombre)}</button>`).join('')
      : '<p class="ayuda" style="color:var(--txt3)">Primero crea una materia en Ajustes.</p>';

    $('#cuerpoHoja').innerHTML = `
      <div class="campo">
        <label for="hTitulo">¿Qué tienes que entregar?</label>
        <input type="text" id="hTitulo" placeholder="Ej: Ensayo de historia" value="${esc(t ? t.titulo : '')}" maxlength="120" autocomplete="off">
        <div class="error" id="eTitulo"></div>
      </div>

      <div class="campo">
        <label>Materia</label>
        <div class="chips-materia" id="hMaterias">${chips}</div>
        <input type="hidden" id="hMateria" value="${esc(t ? t.materia : (materiaFiltro !== '__todas__' ? materiaFiltro : ''))}">
      </div>

      <div class="campo">
        <label for="hFecha">¿Cuándo cierra?</label>
        <div class="fila2">
          <input type="date" id="hFecha" value="${esc(porDefectoF)}">
          <input type="time" id="hHora" value="${esc(porDefectoH)}">
        </div>
        <div class="error" id="eEntrega"></div>
        <div class="ayuda">Te aviso 24 h, 6 h y 1 h antes.</div>
      </div>

      <div class="campo">
        <label>Atajos</label>
        <div class="rangos" id="hRangos">
          <button class="chip-m" data-rapido="hoy23">Hoy 23:59</button>
          <button class="chip-m" data-rapido="manana">Mañana 23:59</button>
          <button class="chip-m" data-rapido="lunes">Lunes</button>
          <button class="chip-m" data-rapido="semana">En una semana</button>
        </div>
      </div>

      <div class="campo">
        <label>Puntos y nota <span style="font-weight:400">(opcional)</span></label>
        <div class="fila2">
          <input type="number" id="hPuntos" min="0" step="0.5" inputmode="decimal" placeholder="10" value="${t && t.puntos !== null ? t.puntos : ''}">
          <input type="number" id="hNota" min="0" step="0.5" inputmode="decimal" placeholder="Tu nota" value="${t && t.nota !== null ? t.nota : ''}">
        </div>
        <div class="error" id="ePuntos"></div>
        <div class="error" id="eNota"></div>
        <div class="ayuda">Con esto ves tu promedio en Ajustes.</div>
      </div>

      <div class="campo">
        <label for="hNotaTexto">Notas <span style="font-weight:400">(opcional)</span></label>
        <textarea id="hNotaTexto" rows="2" placeholder="Ej: entregar por el AVA, en PDF" maxlength="300">${esc(t ? (t.notaTexto || '') : '')}</textarea>
      </div>

      <div class="botones">
        <button class="btn sec" data-cerrar>Cancelar</button>
        <button class="btn" id="hGuardar">${t ? 'Guardar cambios' : 'Agregar tarea'}</button>
      </div>
      ${t ? '<div class="botones" style="margin-top:8px"><button class="btn sec" id="hBorrar" style="color:#e5484d">Borrar esta tarea</button></div>' : ''}
    `;

    // chips de materia
    $('#hMaterias').querySelectorAll('[data-mat]').forEach((c) => {
      c.addEventListener('click', () => {
        $('#hMaterias').querySelectorAll('[data-mat]').forEach((x) => x.classList.remove('on'));
        c.classList.add('on');
        $('#hMateria').value = c.dataset.mat;
      });
    });
    // atajos de fecha
    $('#hRangos').querySelectorAll('[data-rapido]').forEach((b) => {
      b.addEventListener('click', () => {
        const ahora = new Date();
        let d = new Date(ahora);
        if (b.dataset.rapido === 'hoy23') d.setHours(23, 59, 0, 0);
        if (b.dataset.rapido === 'manana') { d.setDate(d.getDate() + 1); d.setHours(23, 59, 0, 0); }
        if (b.dataset.rapido === 'lunes') {
          const diff = (8 - d.getDay()) % 7 || 7;
          d.setDate(d.getDate() + diff); d.setHours(23, 59, 0, 0);
        }
        if (b.dataset.rapido === 'semana') { d.setDate(d.getDate() + 7); d.setHours(23, 59, 0, 0); }
        const dd = desdeEpoch(Math.floor(d.getTime() / 1000));
        $('#hFecha').value = dd.fecha;
        $('#hHora').value = dd.hora;
      });
    });
    $('#hGuardar').addEventListener('click', guardarTarea);
    const btnB = $('#hBorrar');
    if (btnB) btnB.addEventListener('click', () => { const id = editando; cerrarHojas(); borrar(id); });

    abrirHojas();
    setTimeout(() => { const i = $('#hTitulo'); if (i) i.focus(); }, 380);
  }

  function guardarTarea() {
    const payload = {
      titulo: $('#hTitulo').value,
      materia: $('#hMateria').value,
      entrega: aEpoch($('#hFecha').value, $('#hHora').value),
      puntos: $('#hPuntos').value === '' ? null : $('#hPuntos').value,
      nota: $('#hNota').value === '' ? null : $('#hNota').value,
      notaTexto: $('#hNotaTexto').value,
    };
    const err = L.validar(payload);
    ['Titulo', 'Entrega', 'Puntos', 'Nota'].forEach((k) => {
      const caja = $('#e' + k);
      if (caja) {
        caja.textContent = err[k.toLowerCase()] || '';
        caja.classList.toggle('ver', !!err[k.toLowerCase()]);
      }
    });
    $$('#cuerpoHoja input, #cuerpoHoja textarea').forEach((c) => c.classList.remove('err'));
    if (err.titulo) $('#hTitulo').classList.add('err');
    if (err.entrega) $('#hFecha').classList.add('err');
    if (err.puntos) $('#hPuntos').classList.add('err');
    if (err.nota) $('#hNota').classList.add('err');
    if (Object.keys(err).length) { vibrar([40, 60, 40]); return; }

    if (editando) {
      const t = datos.tareas.find((x) => x.id === editando);
      Object.assign(t, payload, { entrega: payload.entrega, puntos: num(payload.puntos), nota: num(payload.nota) });
      brindis('Tarea actualizada', '#4c6ef5', ICONOS.check);
    } else {
      datos.tareas.push(L.crearTarea(Object.assign({}, payload, {
        puntos: num(payload.puntos), nota: num(payload.nota) })));
      brindis('Tarea agregada', '#30a46c', ICONOS.check);
    }
    guardar();
    cerrarHojas();
    pintar();
    revisar(false);
  }

  function num(v) { return (v === null || v === '') ? null : Number(v); }

  /* ══════════════════════════════════════════════════════ HOJAS */
  function abrirHojas() {
    $('#velo').classList.add('abierto');
    setTimeout(() => { $('#hojaTarea').classList.add('abierto'); }, 30);
  }
  function cerrarHojas() {
    $('#hojaTarea').classList.remove('abierto');
    $('#hojaMateria').classList.remove('abierto');
    setTimeout(() => $('#velo').classList.remove('abierto'), 220);
  }
  function abrirMateria(id) {
    const editandoM = id ? datos.materias.find((m) => m.id === id) : null;
    colorElegida = editandoM ? editandoM.color
                             : L.COLORES[datos.materias.length % L.COLORES.length];
    $('#tituloMateria').textContent = editandoM ? 'Editar materia' : 'Nueva materia';
    $('#cuerpoMateria').innerHTML = `
      <div class="campo">
        <label for="mNombre">Nombre de la materia</label>
        <input type="text" id="mNombre" placeholder="Ej: Probabilidad y Estadística" maxlength="60" autocomplete="off" value="${esc(editandoM ? editandoM.nombre : '')}">
        <div class="error" id="eMNombre"></div>
      </div>
      <div class="campo">
        <label>Color</label>
        <div class="colores" id="mColores">
          ${L.COLORES.map((c) => `<button class="color ${c === colorElegida ? 'on' : ''}" data-color="${c}" style="background:${c};color:${c}"></button>`).join('')}
        </div>
      </div>
      <div class="botones">
        <button class="btn sec" data-cerrar>Cancelar</button>
        <button class="btn" id="mGuardar">${editandoM ? 'Guardar' : 'Crear materia'}</button>
      </div>`;
    $('#mColores').querySelectorAll('[data-color]').forEach((b) => {
      b.addEventListener('click', () => {
        $('#mColores').querySelectorAll('.color').forEach((x) => x.classList.remove('on'));
        b.classList.add('on');
        colorElegida = b.dataset.color;
      });
    });
    $('#mGuardar').addEventListener('click', () => {
      const nombre = $('#mNombre').value.trim();
      const e = $('#eMNombre');
      if (!nombre) {
        e.textContent = 'Ponle un nombre a la materia';
        e.classList.add('ver'); $('#mNombre').classList.add('err');
        vibrar([40, 60, 40]);
        return;
      }
      if (editandoM) {
        editandoM.nombre = nombre;
        editandoM.color = colorElegida;
        brindis('Materia actualizada', colorElegida, ICONOS.check);
      } else {
        datos.materias.push({ id: 'm' + Date.now().toString(36), nombre, color: colorElegida });
        brindis('Materia creada', colorElegida, ICONOS.check);
      }
      guardar();
      cerrarHojas();
      pintarAjustes();
      pintar();
    });
    $('#velo').classList.add('abierto');
    setTimeout(() => {
      $('#hojaMateria').classList.add('abierto');
      const i = $('#mNombre'); if (i) i.focus();
    }, 30);
  }

  /* ══════════════════════════════════════════════════════ AJUSTES */
  function abrirAjustes() { pintarAjustes(); $('#pantallaAjustes').classList.add('ver'); }

  function pintarAjustes() {
    const total = L.progreso(datos.tareas);
    const nota = total.nota === null ? '—' : total.nota.toFixed(1);
    const colNota = total.nota === null ? 'var(--txt2)'
      : total.aprobado ? '#2f9e44' : '#e5484d';

    const porMateria = datos.materias.map((m) => {
      const ts = datos.tareas.filter((t) => t.materia === m.id);
      const p = L.progreso(ts);
      const pct = p.posibles > 0 ? Math.min(100, (p.puntos / p.posibles) * 100) : 0;
      return `<div class="materia-fila">
        <i style="background:${m.color}"></i>
        <b data-editar-materia="${esc(m.id)}" style="cursor:pointer">${esc(m.nombre)}</b>
        <span class="c">${p.entregadas}/${p.total} · ${p.puntos}/${p.posibles || 0}</span>
        <button class="icono-btn" data-editar-materia="${esc(m.id)}" style="width:32px;height:32px;box-shadow:none" aria-label="Editar ${esc(m.nombre)}">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="width:15px;height:15px"><path d="M4 20h4L20 8l-4-4L4 16z"/></svg>
        </button>
        <button class="icono-btn" data-borrar-materia="${esc(m.id)}" style="width:32px;height:32px;box-shadow:none" aria-label="Borrar ${esc(m.nombre)}">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="width:15px;height:15px"><path d="M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14"/></svg>
        </button>
      </div>
      <div style="height:6px;border-radius:99px;background:var(--carta2);margin:-4px 0 12px;overflow:hidden">
        <div style="height:100%;width:${pct}%;background:${m.color};border-radius:99px;transition:width .4s ease"></div>
      </div>`;
    }).join('') || '<p style="color:var(--txt3);font-size:13.5px;margin:0 0 12px">Todavía no tienes materias.</p>';

    $('#cuerpoAjustes').innerHTML = `
      <div style="background:var(--carta);border:1px solid var(--linea);border-radius:var(--radio);
                  padding:18px;text-align:center;box-shadow:var(--sombra);margin-bottom:18px">
        <div style="font-size:12px;color:var(--txt2);font-weight:600;letter-spacing:.4px;text-transform:uppercase">Tu promedio general</div>
        <div style="font-size:44px;font-weight:800;letter-spacing:-1.5px;color:${colNota};margin:6px 0 2px">${nota}</div>
        <div style="font-size:13px;color:var(--txt2)">${total.nota === null
          ? 'Puntúa tus tareas para verlo.'
          : (total.aprobado ? 'Aprobado (70 o más)' : 'Por debajo de 70')}</div>
      </div>

      <h3 style="font-size:14px;font-weight:700;margin:0 0 10px">Materias</h3>
      ${porMateria}
      <button class="btn sec" id="aNuevaMateria" style="width:100%;margin-bottom:22px">+ Nueva materia</button>

      <h3 style="font-size:14px;font-weight:700;margin:0 0 10px">Avisos</h3>
      <div style="background:var(--carta);border:1px solid var(--linea);border-radius:var(--radio);padding:4px 14px;margin-bottom:22px">
        <div style="display:flex;align-items:center;justify-content:space-between;padding:13px 0;border-bottom:1px solid var(--linea)">
          <div><b style="font-size:14.5px">Sonido y vibración</b><div style="font-size:12.5px;color:var(--txt2)">AlERTARte cuando se acerque el cierre</div></div>
          <input type="checkbox" id="aSonido" ${datos.avisos ? 'checked' : ''} style="width:22px;height:22px;accent-color:var(--acento)">
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:13px 0">
          <div><b style="font-size:14.5px">Notificaciones</b><div style="font-size:12.5px;color:var(--txt2)">Aviso aunque estés en otra app</div></div>
          <button class="btn" id="aPermiso" style="padding:8px 14px;font-size:13px">${notificacionesOk ? 'Activadas' : 'Activar'}</button>
        </div>
      </div>

      <h3 style="font-size:14px;font-weight:700;margin:0 0 10px">Apariencia</h3>
      <div style="background:var(--carta);border:1px solid var(--linea);border-radius:var(--radio);padding:4px 14px;margin-bottom:22px">
        ${[['claro', 'Claro'], ['oscuro', 'Oscuro'], ['auto', 'Como el sistema']].map(([v, t]) => `
          <button class="tab ${datos.tema === v ? 'on' : ''}" data-tema="${v}" style="width:100%;text-align:left;margin:8px 0">${t}</button>`).join('')}
      </div>

      <h3 style="font-size:14px;font-weight:700;margin:0 0 10px">Tus datos</h3>
      <div style="display:flex;gap:9px;margin-bottom:10px">
        <button class="btn sec" id="aExportar" style="flex:1">Exportar copia</button>
        <button class="btn sec" id="aImportar" style="flex:1">Restaurar</button>
      </div>
      <input type="file" id="aArchivo" accept="application/json" hidden>
      <p style="font-size:12px;color:var(--txt3);line-height:1.5;margin:0 0 22px">
        Todo se guarda solo en este teléfono. Exporta una copia de vez en cuando si te importa.
      </p>
      <button class="btn sec" id="aVaciar" style="width:100%;color:#e5484d">Borrar todas las tareas</button>
      <p style="text-align:center;color:var(--txt3);font-size:11.5px;margin:20px 0 0">Mis Tareas · versión 1</p>
    `;

    const enlaces = $('#cuerpoAjustes');
    enlaces.querySelector('#aNuevaMateria').addEventListener('click', () => abrirMateria(null));
    enlaces.querySelectorAll('[data-editar-materia]').forEach((b) => b.addEventListener('click', () => {
      abrirMateria(b.dataset.editarMateria);
    }));
    enlaces.querySelector('#aSonido').addEventListener('change', (e) => {
      datos.avisos = e.target.checked; guardar();
      if (datos.avisos) { toner(true); brindis('Sonido activado', '#30a46c', ICONOS.check); }
    });
    enlaces.querySelector('#aPermiso').addEventListener('click', pedirNotificaciones);
    enlaces.querySelectorAll('[data-tema]').forEach((b) => b.addEventListener('click', () => {
      datos.tema = b.dataset.tema; aplicarTema(datos.tema); guardar(); pintarAjustes();
    }));
    enlaces.querySelectorAll('[data-borrar-materia]').forEach((b) => b.addEventListener('click', () => {
      const id = b.dataset.borrarMateria;
      const m = nombreMateria(id);
      if (!confirm(`¿Borrar la materia "${m}"? Las tareas NO se borran, quedan sin materia.`)) return;
      datos.materias = datos.materias.filter((x) => x.id !== id);
      datos.tareas.forEach((t) => { if (t.materia === id) t.materia = ''; });
      guardar(); pintarAjustes(); pintar();
    }));
    enlaces.querySelector('#aExportar').addEventListener('click', exportar);
    enlaces.querySelector('#aImportar').addEventListener('click', () => $('#aArchivo').click());
    enlaces.querySelector('#aArchivo').addEventListener('change', importar);
    enlaces.querySelector('#aVaciar').addEventListener('click', () => {
      if (!datos.tareas.length) return;
      if (!confirm(`¿Borrar las ${datos.tareas.length} tareas? Esto no se puede deshacer.`)) return;
      datos.tareas = []; guardar(); pintarAjustes(); pintar();
      brindis('Lista vacía', '#e5484d', ICONOS.basura);
    });
  }

  function exportar() {
    const txt = JSON.stringify(datos, null, 2);
    const blob = new Blob([txt], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    const d = new Date();
    a.download = `mis-tareas-${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    brindis('Copia descargada', '#30a46c', ICONOS.check);
  }

  function importar(ev) {
    const f = ev.target.files[0];
    if (!f) return;
    const lector = new FileReader();
    lector.onload = () => {
      try {
        const d = JSON.parse(lector.result);
        if (!d || !Array.isArray(d.tareas)) throw new Error('formato');
        const n = d.tareas.length;
        datos = Object.assign(porDefecto(), d);
        guardar(); pintarAjustes(); pintar();
        brindis(`${n} tarea(s) restauradas`, '#30a46c', ICONOS.check);
      } catch (e) {
        brindis('Ese archivo no es una copia válida', '#e5484d', ICONOS.aviso);
      }
      ev.target.value = '';
    };
    lector.readAsText(f);
  }

  /* ══════════════════════════════════════════════════════ ONBOARDING */
  function puntosOnboarding() {
    const items = [
      ['#4c6ef5', ICONOS.raya, 'Registras tus tareas', 'El nombre, la materia y cuándo cierra. Nada más.'],
      ['#f76808', ICONOS.aviso, 'Te las ordeno por urgencia', 'Vencida, hoy, mañana, esta semana… cada una con su color.'],
      ['#e5484d', ICONOS.campana, 'Te aviso antes de que se cierren', 'Con sonido y vibración, 24 h, 6 h y 1 h antes.'],
      ['#30a46c', ICONOS.grafico, 'Llevas tu promedio', 'Apunta los puntos de cada tarea y mira cómo vas.'],
    ];
    $('#puntosOnb').innerHTML = items.map(([c, ic, t, s]) =>
      `<li><div class="ic" style="background:${c}">${ic}</div>
        <div><b>${t}</b><span>${s}</span></div></li>`).join('');
  }

  /* ══════════════════════════════════════════════════════ EVENTOS */
  function enlazar() {
    $('#fab').addEventListener('click', () => { vibrar(); abrirHoja(null); });
    $('#btnAjustes').addEventListener('click', abrirAjustes);
    $('#btnTema').addEventListener('click', () => {
      const actual = document.documentElement.getAttribute('data-tema');
      datos.tema = actual === 'oscuro' ? 'claro' : 'oscuro';
      aplicarTema(datos.tema); guardar();
    });
    $('#btnBuscar').addEventListener('click', () => {
      const b = $('#barraBusqueda');
      b.hidden = !b.hidden;
      if (b.hidden) { busqueda = ''; $('#inputBuscar').value = ''; pintarLista(); }
      else $('#inputBuscar').focus();
    });
    $('#inputBuscar').addEventListener('input', (e) => { busqueda = e.target.value; pintarLista(); });

    $('#velo').addEventListener('click', cerrarHojas);
    $$('[data-cerrar]').forEach((b) => b.addEventListener('click', cerrarHojas));
    $$('[data-cerrar-pantalla]').forEach((b) => b.addEventListener('click', () =>
      $('#pantallaAjustes').classList.remove('ver')));

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { cerrarHojas(); $('#pantallaAjustes').classList.remove('ver'); }
    });

    // Resumen también cambia de vista
    $('#resumen').addEventListener('click', (e) => {
      const b = e.target.closest('[data-vista]');
      if (b) cambiarVista(b.dataset.vista);
    });
    $('#tabs').addEventListener('click', (e) => {
      const t = e.target.closest('[data-vista]');
      if (t) { cambiarVista(t.dataset.vista); return; }
      const m = e.target.closest('[data-materia]');
      if (m) { materiaFiltro = m.dataset.materia; pintar(); }
    });

    $('#btnEmpezar').addEventListener('click', () => {
      datos.visto = true; guardar();
      $('#onb').style.display = 'none';
      // Sin esto la app queda invisible: #cuerpo solo se mostraba en el
      // arranque normal, no al terminar el onboarding.
      $('#cuerpo').hidden = false;
      pintar();
      pedirNotificaciones();
    });

    // Al volver a la app, revisa de inmediato: el navegador congela los
    // temporizadores cuando la app está en segundo plano.
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') { aplicarTema(datos.tema); revisar(true); pintar(); }
    });
  }

  /* ══════════════════════════════════════════════════════ MODO DEMO */
  // ?demo=1 llena la app con tareas de ejemplo para ver cómo se ve funcionando.
  // No toca nada real: solo sirve si la lista está vacía.
  function sembrarDemo() {
    // Base = ahora, no el mediodía: si no, una tarea de "16:00" aparece
    // vencida cuando abres la app en la tarde.
    const B = L.ahora();
    const D = 86400, H = 3600;
    datos.materias = MATERIAS_INICIALES.map((m, i) => ({ id: 'd' + i, nombre: m.nombre, color: m.color }));
    const base = [
      ['Tarea 1: espacio muestral',           0, B - 3 * D,  25, 22,  true],
      ['Tarea 2: probabilidad condicional',   0, B + 4 * H,   25, null, false],
      ['Reporte de la unidad 2',              0, B + 2 * D,   20, null, false],
      ['Proyecto integrador',                 0, B + 12 * D,  30, null, false],
      ['Ejercicio 1: senos y cosenos',        1, B + 26 * H,  10, null, false],
      ['Laboratorio 2: derivadas',            1, B + 4 * D,   15, null, false],
      ['Tallado de circuitos RC',             2, B + 6 * H,   12, null, false],
      ['Práctica 3: bisección y secante',     3, B + 5 * D,   15, null, false],
      ['Consultar libro de simulación',       4, null,        null, null, false],
    ];
    datos.tareas = base.map(([titulo, m, entrega, puntos, nota, hecha]) =>
      L.crearTarea({ titulo, materia: 'd' + m, entrega, puntos, nota, notaTexto: '', hecha }, B));
    datos.visto = true;
  }

  /* ══════════════════════════════════════════════════════ INICIO */
  function iniciar() {
    try {
      arrancar();
    } catch (e) {
      mostrarFallo(e && e.message ? e.message : String(e));
    }
  }

  function arrancar() {
    cargar();
    enlazar();
    puntosOnboarding();
    $('#btnBuscar').innerHTML = ICONOS.lupa;
    $('#btnAjustes').innerHTML = ICONOS.engranaje;
    const h = new Date().getHours();
    $('#saludo').textContent = h < 12 ? 'Buenos días' : (h < 19 ? 'Buenas tardes' : 'Buenas noches');

    const q = new URLSearchParams(location.search);
    // ?demo=1 siempre vuelve a sembrar: sirve para ver la app con datos frescos
    if (q.get('demo') === '1') { sembrarDemo(); guardar(); }

    // El onboarding se decide en un solo sitio y siempre explícito: antes solo
    // se ocultaba en un camino, y si no se ocultaba tapaba la app encima.
    const primerVez = !datos.visto;
    $('#onb').style.display = primerVez ? 'flex' : 'none';
    $('#cuerpo').hidden = primerVez;

    if (!primerVez) {
      pintar();
      if ('Notification' in window && Notification.permission === 'granted') notificacionesOk = true;
      revisar(true);
    }
    programar();

    // Atajo del menú de Android: "Nueva tarea"
    if (q.get('nueva') === '1' && !primerVez) {
      setTimeout(() => abrirHoja(null), 500);
    }

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('sw.js').catch(() => {});
    }
  }

  document.addEventListener('DOMContentLoaded', iniciar);

  // Si algo falla, que se vea en pantalla en vez de dejar la app en blanco.
  window.addEventListener('error', (ev) => mostrarFallo(ev.message));
  window.addEventListener('unhandledrejection', (ev) => mostrarFallo(String((ev.reason && ev.reason.message) || ev.reason)));

  function mostrarFallo(msg) {
    try {
      const c = document.createElement('div');
      c.style.cssText = 'position:fixed;left:10px;right:10px;bottom:calc(20px + env(safe-area-inset-bottom,0px));'
        + 'z-index:99;background:#5b1414;color:#ffc9c9;padding:12px 14px;border-radius:12px;'
        + 'font-size:12.5px;line-height:1.5;box-shadow:0 8px 30px rgba(0,0,0,.4)';
      c.textContent = 'Algo falló: ' + msg;
      document.body.appendChild(c);
    } catch (e) { /* si ni esto funciona, no hay mucho más que hacer */ }
  }
})();
